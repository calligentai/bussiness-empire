import { m as medusaRuntime, a as medusaHeaders } from './medusa-client.mjs';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class CheckoutError extends Error {
  constructor(message, statusCode, code) {
    super(message);
    __publicField(this, "statusCode", statusCode);
    __publicField(this, "code", code);
    this.name = "CheckoutError";
  }
}
const text = (value) => typeof value === "string" ? value.trim() : "";
const assertSandbox = (env) => {
  const appEnv = text(env.APP_ENV) || "development";
  if (appEnv === "production") {
    throw new CheckoutError(
      "Sandbox checkout is disabled when APP_ENV is production",
      403,
      "production_disabled"
    );
  }
  const stripe = text(env.STRIPE_SECRET_KEY);
  const mollie = text(env.MOLLIE_API_KEY);
  if (stripe.startsWith("sk_live_") || stripe.startsWith("rk_live_") || mollie.startsWith("live_")) {
    throw new CheckoutError("Live payment keys are refused", 403, "live_payment_refused");
  }
  const provider = (text(env.PAYMENT_PROVIDER) || "manual").toLowerCase();
  if (provider === "manual" || provider === "pp_system_default") return;
  if (provider === "stripe") {
    throw new CheckoutError(
      "Stripe test mode is not called by this build. Set PAYMENT_PROVIDER=manual. Stripe test would use STRIPE_SECRET_KEY=sk_test_... and STRIPE_WEBHOOK_SECRET.",
      501,
      "stripe_test_unwired"
    );
  }
  if (provider === "mollie") {
    throw new CheckoutError(
      "Mollie test mode is not called by this build. Set PAYMENT_PROVIDER=manual. Mollie test would use MOLLIE_API_KEY=test_...",
      501,
      "mollie_test_unwired"
    );
  }
  throw new CheckoutError("Unknown payment provider", 400, "unknown_provider");
};
const namespaceOf = (options) => options.dataDir || "default";
const placeOrder = async (input, options = {}) => {
  var _a;
  const env = (_a = options.env) != null ? _a : {};
  assertSandbox(env);
  const runtime = medusaRuntime();
  const response = await fetch(`${runtime.backendUrl}/store/lavabean/checkout`, {
    method: "POST",
    headers: medusaHeaders(namespaceOf(options)),
    body: JSON.stringify(input)
  });
  const body = await response.json();
  if (!response.ok) {
    throw new CheckoutError(body.message || "Checkout failed", response.status, body.code || "checkout_failed");
  }
  return body;
};
const getOrder = async (id, options = {}) => {
  const orderId = text(id);
  if (!orderId) return void 0;
  const runtime = medusaRuntime();
  const response = await fetch(
    `${runtime.backendUrl}/store/lavabean/orders/${encodeURIComponent(orderId)}`,
    { headers: medusaHeaders(namespaceOf(options)) }
  );
  if (response.status === 404) return void 0;
  const body = await response.json();
  if (!response.ok) {
    throw new CheckoutError(body.message || "Order lookup failed", response.status, body.code || "order_lookup_failed");
  }
  return body;
};

export { CheckoutError as C, getOrder as g, placeOrder as p };
//# sourceMappingURL=store.mjs.map
