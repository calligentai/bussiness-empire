import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const readJson = (path) => {
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch {
    return {};
  }
};
const medusaRuntime = () => {
  const fromFile = readJson(join(process.cwd(), "apps/medusa/.runtime.json"));
  const keyFile = process.env.MEDUSA_PUBLISHABLE_KEY_FILE;
  const keyFromFile = keyFile ? readJson(keyFile).publishableKey : void 0;
  const runtime = {
    backendUrl: process.env.MEDUSA_BACKEND_URL || fromFile.backendUrl || "",
    publishableKey: process.env.MEDUSA_PUBLISHABLE_KEY || keyFromFile || fromFile.publishableKey || "",
    internalToken: process.env.LAVABEAN_INTERNAL_TOKEN || fromFile.internalToken || "",
    adminEmail: process.env.MEDUSA_ADMIN_EMAIL || fromFile.adminEmail || "",
    adminPassword: process.env.MEDUSA_ADMIN_PASSWORD || fromFile.adminPassword || ""
  };
  if (!runtime.backendUrl || !runtime.publishableKey) {
    throw new Error("Medusa is not configured. Start apps/medusa and write apps/medusa/.runtime.json.");
  }
  return runtime;
};
const medusaHeaders = (namespace) => {
  const runtime = medusaRuntime();
  const headers = {
    "content-type": "application/json",
    "x-publishable-api-key": runtime.publishableKey
  };
  if (runtime.internalToken) {
    headers["x-lavabean-internal-token"] = runtime.internalToken;
    headers["x-lavabean-namespace"] = namespace || "default";
  }
  return headers;
};

export { medusaHeaders as a, medusaRuntime as m };
//# sourceMappingURL=medusa-client.mjs.map
