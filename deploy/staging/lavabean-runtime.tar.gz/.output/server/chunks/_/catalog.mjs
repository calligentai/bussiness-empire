import { m as medusaRuntime, a as medusaHeaders } from './medusa-client.mjs';

const toCents = (amount) => amount <= 100 ? Math.round(amount * 100) : Math.round(amount);
const text = (metadata, key) => typeof (metadata == null ? void 0 : metadata[key]) === "string" ? metadata[key] : "";
const toStorefrontProduct = (product) => {
  var _a, _b, _c, _d, _e, _f, _g, _h;
  const variants = (_a = product.variants) != null ? _a : [];
  const sizes = variants.length > 1 ? variants.map((variant2) => {
    var _a2, _b2, _c2;
    return {
      id: ((_a2 = variant2.metadata) == null ? void 0 : _a2.fixture_variant_id) || variant2.id,
      label: variant2.title,
      priceCents: toCents((_c2 = (_b2 = variant2.calculated_price) == null ? void 0 : _b2.calculated_amount) != null ? _c2 : 0)
    };
  }).sort((left, right) => left.priceCents - right.priceCents) : void 0;
  const variant = variants[0];
  const amount = sizes ? Math.min(...sizes.map((size) => size.priceCents)) : toCents((_c = (_b = variant == null ? void 0 : variant.calculated_price) == null ? void 0 : _b.calculated_amount) != null ? _c : 0);
  const brand = text(product.metadata, "brand");
  const imageSrc = product.thumbnail || ((_e = (_d = product.images) == null ? void 0 : _d[0]) == null ? void 0 : _e.url) || "";
  const imageAlt = text(product.metadata, "imageAlt");
  const recipeLabel = text(product.metadata, "recipeLabel");
  return {
    slug: product.handle,
    name: product.title,
    origin: text(product.metadata, "origin"),
    process: text(product.metadata, "process"),
    notes: Array.isArray((_f = product.metadata) == null ? void 0 : _f.notes) ? (_g = product.metadata) == null ? void 0 : _g.notes : [],
    roast: text(product.metadata, "roast"),
    priceCents: amount,
    ...!sizes && (variant == null ? void 0 : variant.title) ? { unitLabel: variant.title } : {},
    altitude: text(product.metadata, "altitude"),
    recipe: text(product.metadata, "recipe"),
    ...brand ? { brand, description: (_h = product.description) != null ? _h : "" } : {},
    ...recipeLabel ? { recipeLabel } : {},
    ...imageSrc && imageAlt ? { image: { src: imageSrc, alt: imageAlt } } : {},
    ...sizes ? { sizes } : {}
  };
};
let regionId;
const region = async () => {
  var _a;
  if (regionId) return regionId;
  const runtime = medusaRuntime();
  const response = await fetch(`${runtime.backendUrl}/store/regions`, { headers: medusaHeaders() });
  if (!response.ok) throw new Error(`Medusa regions failed (${response.status})`);
  const body = await response.json();
  const match = (_a = body.regions) == null ? void 0 : _a.find((item) => item.currency_code === "eur");
  if (!match) throw new Error("Medusa has no EUR region");
  regionId = match.id;
  return regionId;
};
const fetchCatalog = async (handle) => {
  var _a;
  const runtime = medusaRuntime();
  const region_id = await region();
  const params = new URLSearchParams({
    limit: "20",
    region_id,
    fields: "*variants,*variants.calculated_price,*variants.metadata,+metadata"
  });
  if (handle) params.set("handle", handle);
  const response = await fetch(`${runtime.backendUrl}/store/products?${params}`, {
    headers: medusaHeaders()
  });
  if (!response.ok) throw new Error(`Medusa products failed (${response.status})`);
  const body = await response.json();
  return ((_a = body.products) != null ? _a : []).map(toStorefrontProduct);
};

export { fetchCatalog as f };
//# sourceMappingURL=catalog.mjs.map
