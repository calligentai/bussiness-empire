import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { f as fetchCatalog } from '../../_/catalog.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../_/medusa-client.mjs';

const catalog_get = defineEventHandler(async () => fetchCatalog());

export { catalog_get as default };
//# sourceMappingURL=catalog.get.mjs.map
