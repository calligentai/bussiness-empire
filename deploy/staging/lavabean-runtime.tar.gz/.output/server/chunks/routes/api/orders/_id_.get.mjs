import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../nitro/nitro.mjs';
import { g as getOrder } from '../../../_/store.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/medusa-client.mjs';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const id = (_a = getRouterParam(event, "id")) != null ? _a : "";
  const order = await getOrder(decodeURIComponent(id), { env: process.env });
  if (!order) {
    throw createError({ statusCode: 404, statusMessage: "Order not found" });
  }
  return order;
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
