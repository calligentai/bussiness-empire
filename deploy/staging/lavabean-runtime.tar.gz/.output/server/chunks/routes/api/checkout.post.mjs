import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import { p as placeOrder, C as CheckoutError } from '../../_/store.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../_/medusa-client.mjs';

const checkout_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  try {
    return await placeOrder(body != null ? body : {}, { env: process.env });
  } catch (error) {
    if (error instanceof CheckoutError) {
      throw createError({
        statusCode: error.statusCode,
        statusMessage: error.message,
        data: { code: error.code }
      });
    }
    throw error;
  }
});

export { checkout_post as default };
//# sourceMappingURL=checkout.post.mjs.map
