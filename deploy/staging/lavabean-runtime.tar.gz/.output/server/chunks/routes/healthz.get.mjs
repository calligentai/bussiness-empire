import { d as defineEventHandler } from '../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const healthz_get = defineEventHandler(() => {
  var _a, _b;
  return {
    status: "ok",
    environment: (_a = process.env.APP_ENV) != null ? _a : "development",
    revision: (_b = process.env.APP_REVISION) != null ? _b : "local"
  };
});

export { healthz_get as default };
//# sourceMappingURL=healthz.get.mjs.map
